﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace TechMeetup
{
    public partial class Form1 : Form
    {
        MySqlConnection conn = new MySqlConnection("server=localhost;user=root;database=techmeetup;port=3306;password=");
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string user;
            string pass;

            string sql = "SELECT * FROM user";

            conn.Open();
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            using (MySqlDataReader dr = cmd.ExecuteReader())
            {
                if (dr.Read())
                {
                    user = dr["username"].ToString();
                    pass= dr["password"].ToString();

                    if (txtuser.Text == user)
                    {
                        if(txtpass.Text == pass)
                        {
                            home hm = new home();
                            this.Hide();
                            hm.Show();
                            MessageBox.Show("Username and password are matched", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtuser.Text = "";
                            txtpass.Text = "";
                        }
                        else
                        {
                            MessageBox.Show("password mismatched", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            txtuser.Text = "";
                            txtpass.Text = "";
                        }

                    }
                    else
                    {
                        MessageBox.Show("username and password mismatched", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtuser.Text = "";
                        txtpass.Text = "";
                    }
                }
            }

            conn.Close();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
